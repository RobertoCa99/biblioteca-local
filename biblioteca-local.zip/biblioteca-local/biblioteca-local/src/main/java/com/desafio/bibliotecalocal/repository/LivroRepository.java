package com.desafio.bibliotecalocal.repository;

import com.desafio.bibliotecalocal.entity.Livros;
import org.antlr.v4.runtime.misc.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Repository
public interface LivroRepository extends JpaRepository<Livros, Long> {
}
