package com.desafio.bibliotecalocal.controller;

import com.desafio.bibliotecalocal.entity.Livros;
import com.desafio.bibliotecalocal.entity.Reserva;
import com.desafio.bibliotecalocal.repository.LivroRepository;
import com.desafio.bibliotecalocal.repository.ReservaRepository;
import com.desafio.bibliotecalocal.service.LivrosService;
import com.desafio.bibliotecalocal.service.ReservaService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping
public class BibliotecaController {

    @Autowired
    LivroRepository livroRepository;
    ReservaRepository reservaRepository;


    @PostMapping("books")
    public ResponseEntity<Livros> saveProduct(@RequestBody @Validated LivrosService livrosService) {
        var Livros = new Livros();
        BeanUtils.copyProperties(livrosService, Livros);
        return ResponseEntity.status(HttpStatus.CREATED).body(livroRepository.save(Livros));
    }


    @GetMapping("/api/books")
    public ResponseEntity<List<Livros>> getAllLivros(){
        List<Livros> listalivros = livroRepository.findAll();
        if(!listalivros.isEmpty()) {
            for(Livros livros : listalivros) {
                long Id = livros.getId();
                livros.add(linkTo(methodOn(BibliotecaController.class).getOneLivros(Id)).withSelfRel());
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(listalivros);
    }

    @PutMapping("/api/reserve")
    public ResponseEntity<Object> updateProduct(@PathVariable(value="id") long id,
                                                @RequestBody @Validated ReservaService reservaService) {
        Optional<Reserva> reserva = reservaRepository.findById(id);
        if(reserva.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Não encontrada");
        }
        var productModel = reserva.get();
        BeanUtils.copyProperties(reservaService, reserva);
        return ResponseEntity.status(HttpStatus.OK).body(reservaRepository.save(productModel));
    }

    @DeleteMapping("/api/cancel")
    public ResponseEntity<Object> deleteProduct(@PathVariable(value="id") long id) {
        Optional<Reserva> reserva = reservaRepository.findById(id);
        if(reserva.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Não encontrada");
        }
        reservaRepository.delete(reserva.get());
        return ResponseEntity.status(HttpStatus.OK).body("Reserva deletada");
    }

}