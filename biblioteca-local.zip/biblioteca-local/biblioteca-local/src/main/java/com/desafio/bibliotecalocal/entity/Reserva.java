package com.desafio.bibliotecalocal.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class Reserva {

    @Id
    @GeneratedValue
    Long Idr;
    LocalDateTime datareserva;

    public Long getId() {
        return Idr;
    }

    public void setId(Long id) {
        Idr = id;
    }

    public LocalDateTime getDatareserva() {
        return datareserva;
    }

    public void setDatareserva(LocalDateTime datareserva) {
        this.datareserva = datareserva;
    }
}
