package com.desafio.bibliotecalocal;

import com.desafio.bibliotecalocal.service.LivrosService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaLocalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaLocalApplication.class, args);
	}




}
