package com.desafio.bibliotecalocal.repository;

import com.desafio.bibliotecalocal.entity.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
}
