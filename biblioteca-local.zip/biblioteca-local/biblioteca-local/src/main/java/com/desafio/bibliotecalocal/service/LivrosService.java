package com.desafio.bibliotecalocal.service;

import com.desafio.bibliotecalocal.entity.Livros;
import com.desafio.bibliotecalocal.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public record LivrosService(LivroRepository livroRepository) {

    /*public Livros salvar(Livros livros){
        return livroRepository.save(livros);
    }*/

}
