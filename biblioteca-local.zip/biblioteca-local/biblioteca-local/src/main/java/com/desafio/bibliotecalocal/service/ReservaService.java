package com.desafio.bibliotecalocal.service;

import com.desafio.bibliotecalocal.repository.ReservaRepository;

public record ReservaService(ReservaRepository reservaRepository) {
}
