package com.desafio.bibliotecalocal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaLocalApplicationTests {

	@Test
	void contextLoads() {
	}

}
